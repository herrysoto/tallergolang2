package entidad


type UpdateHH struct {
    NUMPRECIOOFICIAL  float64 `db:"NUMPRECIOOFICIAL" json:"numpreciooficial"`
}